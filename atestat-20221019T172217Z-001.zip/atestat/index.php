<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MHP-Főoldal</title>
    <link rel="stylesheet" href="style.css" type="text/css">
    <!--Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!--Font Awesome-->
    <script src="https://kit.fontawesome.com/d694b10655.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <div class="website-header">
            <img src="images/keklogo.jpg" alt="logo">
            <h1>MAGYAR HÍREK PÁLYAUDVARA</h1>
            <div class="social-icons">
                <a href="index.php"><i class="fas fa-home"></i></a>
                <a href="https://www.facebook.com/boti.szilagyi.1/"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/BotiSzilagyi"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/szilagyiboti/"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <nav class="navbar navbar-expand-md ">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">LEGOLVASOTTABB</a>
                        <div class="dropdown-content">
                            <a href="https://telex.hu">TELEX</a>
                            <a href="https://www.origo.hu/index.html">ORIGO (INNEN NINCS VISSZAÚT)</a>
                            <a href="https://hirado.hu">HÍRADÓ (SAJÁT FELELŐSSÉG)</a>
                            <a href="https://444.hu">444</a>
                            <a href="https://hvg.hu">HVG</a>
                            <a href="https://24.hu">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">BELFÖLD</a>
                        <div class="dropdown-content">
                            <a href="https://telex.hu/rovat/belfold">TELEX</a>
                            <a href=https://www.origo.hu/itthon/index.html>ORIGO</a>
                            <a href="https://hirado.hu/belfold/">HÍRADÓ</a>
                            <a href="https://444.hu/category/belfold">444</a>
                            <a href="https://hvg.hu/itthon">HVG</a>
                            <a href="https://24.hu/belfold/">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">KÜLFÖLD</a>
                        <div class="dropdown-content">
                            <a href="https://telex.hu/rovat/kulfold">TELEX</a>
                            <a href="https://www.origo.hu/nagyvilag/index.html">ORIGO</a>
                            <a href="https://hirado.hu/kulfold/">HÍRADÓ</a>
                            <a href="https://444.hu/category/kulfold">444</a>
                            <a href="https://hvg.hu/vilag">HVG</a>
                            <a href="https://24.hu/kulfold/">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">SPORT</a>
                        <div class="dropdown-content">
                            <a href="https://www.nemzetisport.hu">NEMZETI SPORT</a>
                            <a href="https://www.origo.hu/sport/index.html">ORIGO</a>
                            <a href="https://m4sport.hu">M4 SPORT</a>
                            <a href="https://hirado.hu/sport">HÍRADÓ</a>
                            <a href="https://444.hu/category/sport">444</a>
                            <a href="https://hvg.hu/sport">HVG</a>
                            <a href="https://sport24.24.hu">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">TÉNYFELTÁRÓ</a>
                        <div class="dropdown-content">
                            <a href="https://www.direkt36.hu">DIREKT 36</a>
                            <a href="https://youtube.com/playlist?list=PLiQ1IThs1NNOvhuEd5RLr3DjNimxcsqNk">PARTIZÁN</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">VIDEÓ</a>
                        <div class="dropdown-content">
                            <a href="https://www.youtube.com/c/Partizánmédia">PARTIZÁN</a>
                            <a href=https://telex.hu/rovat/video>TELEX</a>
                            <a href="https://hirado.hu/videok/">HÍRADÓ</a>
                            <a href="https://www.youtube.com/user/jetivideo">444</a>
                            <a href="https://www.youtube.com/user/HVGonline">HVG</a>
                            <a href="https://www.youtube.com/c/24huvideo">24.HU</a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="breaking-news-section">
            <span id="btext">Forró hírek</span>
            <marquee direction="left" onmouseover="this.stop()" onmouseout="this.start()">
                <a href="https://transtelex.ro" class="breaking-news">
                    <p class="bntime">16 April 2022</p>
                    Transtelex megalakult
                </a>
                <a href="https://www.youtube.com/watch?v=Spdgk_dkVCc" class="breaking-news">
                    <p class="bntime">9 April 2022</p>
                    Új Magyar Jeti rész
                </a>
                <a href="https://www.politico.eu/article/janez-jansa-suffers-heavy-defeat-as-newcomer-party-wins-slovenian-election/" class="breaking-news">
                    <p class="bntime">25 April 2022</p>
                    Szlovén választások legfrissebb
                </a>
                <a href="https://www.agerpres.ro/politica-externa/2022/04/25/kievul-atentioneaza-ca-nu-exista-niciun-acord-cu-rusia-asupra-unui-coridor-umanitar-din-azovstal--907487" class="breaking-news">
                    <p class="bntime">25 April 2022</p>
                    Legfrissebb Mariupolbol románul
                </a>
            </marquee>
        </div>
    </header>
    <main>
        <article id="popular-news">
            <div id="featured">
                <h2>BOMBA HÍREK</h2>
                <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"></li>
                        <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"></li>
                        <li data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="images/MacronMain.webp" alt="First slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h5>Macron újra francia elnök</h5>
                                <p>Bővebben a külföldi rovatok közt</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/trump.jpg" alt="Second slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h5>Napi 10 ezer dolláros büntetést szabott ki Donald Trumpra a bíróság</h5>
                                <p>Bővebben a külföldi rovatok közt</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="images/ujhelyi2.jpg" alt="Third slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h5>Ujhelyi István bejelentkezett az MSZP, vagyis az elképzelt új szociáldemokrata párt vezetésére</h5>
                                <p>Bővebben a belföldi rovatok közt</p>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>


            </div>
            <div id="latest">
                <h2>LEGÚJABB</h2>
                <section class="news">
                    <div class="news-container">
                        <img src="images/jakszi2.jpg" alt="">
                        <p class="popular-news-text">Jakab Péter diagramokkal magyarázkodik</p>
                    </div>
                </section>
                <section class="news">
                    <div class="news-container">
                        <img src="images/momentum.jpg" alt="">
                        <p class="popular-news-text">A Momentum csak bizonyos feltételek mellett ülne be a parlamentbe
                        </p>
                    </div>
                </section>
            </div>
            <div id="our-picks">
                <h2>IRÓNIA</h2>
                <section class="news">
                    <div class="news-container">
                        <a href="https://kontra.hu/egy-fontos-lista-azokrol-a-tevekenysegekrol-amelyek-megvedenek-attol-hogy-baloldaliva-valjunk"><img src="images/kontra.jpg" alt=""></a>
                        <p class="popular-news-text">Egy fontos lista azokról a tevékenységekről, amelyek megvédenek attól, hogy baloldalivá váljunk</p>
                    </div>
                </section>
                <section class="news">
                    <div class="news-container">
                        <a href="https://telex.hu/belfold/2021/10/17/jakab-andras-alkotmanyjogasz-interju-feles-tobbseggel-alkotmanyozas-alaptorveny-semmis-polgarhaboru"><img src="images/parlament.jpg" alt=""></a>
                        <p class="popular-news-text">A NER-nek kétharmaddal se, az ellenzéknek sima többséggel is? </p>
                    </div>
                </section>
            </div>
        </article>
        <section class="more-news">
            <div class="news-section">
                <article class="world">
                    <h2>NAPI TURNUSVEZETŐ</h2>
                    <img src="images/578A0815.jpg" alt="">
                    <h3>Szilágyi Botond</h3>
                    <p>Elérhetőség: szilagyiboti@yahoo.com</p>
                    <p> Telefonszám: +40741425111</p>
                </article>
                <article class="reki">
                    <h2>REKLÁM HELYE</h2>
                    <img src="images/bolyai.jpg" alt="">
                    <h3>Reklám</h3>
                    <p>Itt megteheted</p>
                </article>
                <article class="en">
                    <h2>Portálok info</h2>
                    <img src="images/gond.jpg" alt="">
                    <h3>Szeretnél több elérhetőséget a portálokhoz?</h3>
                    <p>A következő mező pont ezeket tartalmazza</p>
                </article>
            </div>
            <aside>
                <h4>Portálok elérhetőségei</h4>
                <div class="recent-news">
                    <img src="images/telex.jpg" alt="">
                    <p><a href="https://telex.hu/dokumentum/impresszum" style="text-decoration: none; color:white">Telex.hu</a></p>
                </div>
                <div class="recent-news">
                    <img src="images/444.png" alt="">
                    <p><a href="https://444.hu/impresszum" style="text-decoration: none; color:white">444.hu</a></p>
                </div>
                <div class="recent-news">
                    <img src="images/origo.jpg" alt="">
                    <p><a href="https://www.origo.hu/impresszum/index.html" style="text-decoration: none; color:white">Origo.hu</a></p>
                </div>
                <div class="recent-news"><img src="images/hirado.png" alt="">
                    <p><a href="https://hirado.hu/impresszum/" style="text-decoration: none; color:white">Híradó.hu</a></p>
                </div>
                <div class="recent-news"><img src="images/24.png" alt="">
                    <p><a href="https://24.hu/impresszum/" style="text-decoration: none; color:white">24.hu</a></p>
                </div>
                <div class="recent-news"><img src="images/hvg.png" alt="">
                    <p><a href="https://hvg.hu/egyeb/impresszum" style="text-decoration: none; color:white">HVG.hu</a></p>
                </div>
            </aside>
        </section>
    </main>
    <footer>
        <div class="social-links">
            <section class="about">
                <h2>About</h2>
                <p>Üdvözölünk a magyar internetes hírcsatornák gyűjtőhelyén, ahol arra törekszünk, hogy megmutassuk neked külöböző népszerű hírportálok cikkjeit. Ha tetszik amit csinálunk, akkor kövess minket Facebookon, Instagramon vagy Twitteren, hogy ne maradj le az újdonságokról a honlapon. Ha esetleg segíteni szeretnéd munkánkat, akkor bátran csatlakozz aktivistának, egy rövid űrlapot kitöltve.</p><br>
                <p>Telefonos elérhetőség: +40741425111</p><br>
                <p>Az alábbi oldalakon elérheted koordinátorunkat:</p>
                <div class="social-icons-footer">
                    <a href="https://www.facebook.com/boti.szilagyi.1/"><i class="fab fa-facebook"></i></a>
                    <a href="https://twitter.com/BotiSzilagyi"><i class="fab fa-twitter-square"></i></a>
                    <a href="https://www.instagram.com/szilagyiboti/"><i class="fab fa-instagram"></i></a>
                </div>
            </section>

            <section class="subscribe">
                <h2 style="text-align: center;">Jelentkezz aktivistának</h2>
                <p style="text-align: center;">Légy részese egy dinamikus csapatnak a gombra kattintva</p>
                <a href="jelentkezz.php" style="text-decoration: none;"><button type="button" class="footer-button">Jelentkezem</button></a>
            </section>
        </div>
        <div class="copyright">Szilágyi Botond - Bolyai Farkas Elméleti Líceum - XII.E</div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>