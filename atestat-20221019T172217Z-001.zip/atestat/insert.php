<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$bday = $_POST['bday'];
$email = $_POST['email'];

function Redirect($url, $permanent = false)
{
    header('Location: ' . $url, true, $permanent ? 301 : 302);
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'kerdoiv');
if ($conn->connect_error) {
    echo "$conn->connect_error";
    die("Connection Failed : " . $conn->connect_error);
} else {
    $stmt = $conn->prepare("INSERT INTO `jelentkezes`(`fname`, `lname`, `bday`, `email`) VALUES ('$fname','$lname','$bday','$email')");
    $execval = $stmt->execute();
    echo '<script>alert("Sikeres regisztracio")</script>';
    sleep(1);
    echo "Registration successfully...";
    $stmt->close();
    $conn->close();
    Redirect('index.php', false);
}
