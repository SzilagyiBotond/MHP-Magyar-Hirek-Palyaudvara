<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MHP-Aktivista</title>
    <link rel="stylesheet" href="style.css" type="text/css">
    <!--Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!--Font Awesome-->
    <script src="https://kit.fontawesome.com/d694b10655.js" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <div class="website-header">
            <img src="images/keklogo.jpg" alt="logo">
            <h1>MAGYAR HÍREK PÁLYAUDVARA</h1>
            <div class="social-icons">
                <a href="index.php"><i class="fas fa-home"></i></a>
                <a href="https://www.facebook.com/boti.szilagyi.1/"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/BotiSzilagyi"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/szilagyiboti/"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <nav class="navbar navbar-expand-md ">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">LEGOLVASOTTABB</a>
                        <div class="dropdown-content">
                            <a href="https://telex.hu">TELEX</a>
                            <a href="https://www.origo.hu/index.html">ORIGO (INNEN NINCS VISSZAÚT)</a>
                            <a href="https://hirado.hu">HÍRADÓ (SAJÁT FELELŐSSÉG)</a>
                            <a href="https://444.hu">444</a>
                            <a href="https://hvg.hu">HVG</a>
                            <a href="https://24.hu">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">BELFÖLD</a>
                        <div class="dropdown-content">
                            <a href="https://telex.hu/rovat/belfold">TELEX</a>
                            <a href=https://www.origo.hu/itthon/index.html>ORIGO</a>
                            <a href="https://hirado.hu/belfold/">HÍRADÓ</a>
                            <a href="https://444.hu/category/belfold">444</a>
                            <a href="https://hvg.hu/itthon">HVG</a>
                            <a href="https://24.hu/belfold/">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">KÜLFÖLD</a>
                        <div class="dropdown-content">
                            <a href="https://telex.hu/rovat/kulfold">TELEX</a>
                            <a href="https://www.origo.hu/nagyvilag/index.html">ORIGO</a>
                            <a href="https://hirado.hu/kulfold/">HÍRADÓ</a>
                            <a href="https://444.hu/category/kulfold">444</a>
                            <a href="https://hvg.hu/vilag">HVG</a>
                            <a href="https://24.hu/kulfold/">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">SPORT</a>
                        <div class="dropdown-content">
                            <a href="https://www.nemzetisport.hu">NEMZETI SPORT</a>
                            <a href="https://www.origo.hu/sport/index.html">ORIGO</a>
                            <a href="https://m4sport.hu">M4 SPORT</a>
                            <a href="https://hirado.hu/sport">HÍRADÓ</a>
                            <a href="https://444.hu/category/sport">444</a>
                            <a href="https://hvg.hu/sport">HVG</a>
                            <a href="https://sport24.24.hu">24.HU</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">TÉNYFELTÁRÓ</a>
                        <div class="dropdown-content">
                            <a href="https://www.direkt36.hu">DIREKT 36</a>
                            <a href="https://youtube.com/playlist?list=PLiQ1IThs1NNOvhuEd5RLr3DjNimxcsqNk">PARTIZÁN</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">VIDEÓ</a>
                        <div class="dropdown-content">
                            <a href="https://www.youtube.com/c/Partizánmédia">PARTIZÁN</a>
                            <a href=https://telex.hu/rovat/video>TELEX</a>
                            <a href="https://hirado.hu/videok/">HÍRADÓ</a>
                            <a href="https://www.youtube.com/user/jetivideo">444</a>
                            <a href="https://www.youtube.com/user/HVGonline">HVG</a>
                            <a href="https://www.youtube.com/c/24huvideo">24.HU</a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="breaking-news-section">
            <span id="btext">Forró hírek</span>
            <marquee direction="left" onmouseover="this.stop()" onmouseout="this.start()">
                <a href="https://transtelex.ro" class="breaking-news">
                    <p class="bntime">16 April 2022</p>
                    Transtelex megalakult
                </a>
                <a href="https://www.youtube.com/watch?v=Spdgk_dkVCc" class="breaking-news">
                    <p class="bntime">9 April 2022</p>
                    Új Magyar Jeti rész
                </a>
                <a href="https://www.politico.eu/article/janez-jansa-suffers-heavy-defeat-as-newcomer-party-wins-slovenian-election/" class="breaking-news">
                    <p class="bntime">25 April 2022</p>
                    Szlovén választások legfrissebb
                </a>
                <a href="https://www.agerpres.ro/politica-externa/2022/04/25/kievul-atentioneaza-ca-nu-exista-niciun-acord-cu-rusia-asupra-unui-coridor-umanitar-din-azovstal--907487" class="breaking-news">
                    <p class="bntime">25 April 2022</p>
                    Legfrissebb Mariupolbol románul
                </a>
            </marquee>
        </div>
    </header>
    <main>
        <form action="insert.php" class="form" method="post">
            <br>
            <h1>Jelentkezz aktivistának</h1><br><br>
            <label for="fname">Vezetéknév:</label><br>
            <input type="text" id="fname" name="fname" value=""><br>
            <label for="lname">Keresztnév:</label><br>
            <input type="text" id="lname" name="lname" value=""><br>
            <label for="date">Születési dátum</label><br>
            <input type="date" id="bday" name="bday" value=""><br>
            <label for="email">E-mail-cím</label><br>
            <input type="email" name="email" id="email"><br><br><br><br>
            <input type="submit" value="Feltölt" class="footer-button">
        </form>
    </main>
    <footer>
        <div class="social-links">
            <section class="about">
                <h2>About</h2>
                <p>Üdvözölünk a magyar internetes hírcsatornák gyűjtőhelyén, ahol arra törekszünk, hogy megmutassuk neked külöböző népszerű hírportálok cikkjeit. Ha tetszik amit csinálunk, akkor kövess minket Facebookon, Instagramon vagy Twitteren, hogy ne maradj le az újdonságokról a honlapon. Ha esetleg segíteni szeretnéd munkánkat, akkor bátran csatlakozz aktivistának, egy rövid űrlapot kitöltve.</p><br>
                <p>Telefonos elérhetőség: +40741425111</p><br>
                <p>Az alábbi oldalakon elérheted koordinátorunkat:</p>
                <div class="social-icons-footer">
                    <a href="https://www.facebook.com/boti.szilagyi.1/"><i class="fab fa-facebook"></i></a>
                    <a href="https://twitter.com/BotiSzilagyi"><i class="fab fa-twitter-square"></i></a>
                    <a href="https://www.instagram.com/szilagyiboti/"><i class="fab fa-instagram"></i></a>
                </div>
            </section>

            <section class="subscribe">
                <h2 style="text-align: center;">Jelentkezz aktivistának</h2>
                <p style="text-align: center;">Légy részese egy dinamikus csapatnak a gombra kattintva</p>
                <a href="jelentkezz.php" style="text-decoration: none;"><button type="button" class="footer-button">Jelentkezem</button></a>
            </section>
        </div>
        <div class="copyright">Szilágyi Botond - Bolyai Farkas Elméleti Líceum - XII.E</div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>