<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = "kerdoiv";
$conn = mysqli_connect($servername, $username, $password, "$dbname");
